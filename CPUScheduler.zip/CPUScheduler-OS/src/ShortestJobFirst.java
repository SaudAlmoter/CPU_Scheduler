import java.util.Collections;
import java.util.List;

public class ShortestJobFirst extends CPUScheduler{
	@Override
	public void process(){
		List<Process> Processs = Utility.deepCopy(this.getProcesss());
		int time = Processs.get(0).getArrivalTime();
		//Because its passed by refrence		
		while (!Processs.isEmpty()){			
			Collections.sort(Processs, (Object o1, Object o2) -> {
			if (((Process) o1).getBurstTime() == ((Process) o2).getBurstTime())
				return 0;
			else if (((Process) o1).getBurstTime() < ((Process) o2).getBurstTime())
				return -1;
			else
				return 1;
			});//Collections.sort			
			Process Process = Processs.get(0);
			this.getTimeline().add(new Event(Process.getProcessName(), time, time + Process.getBurstTime()));
			time += Process.getBurstTime();

			for (int i = 0; i < Processs.size(); i++)
				if (Processs.get(i).getProcessName().equals(Process.getProcessName())){
					Processs.remove(i);
					break;
				}//if			
		}//while
		for(Process Process : this.getProcesss()){
			Process.setWaitingTime(this.getEvent(Process).getStartTime() - Process.getArrivalTime());
			Process.setTurnaroundTime(Process.getWaitingTime() + Process.getBurstTime());
		}//for
	}//process
	@Override
	public void setTimeQuantum(int timeQuantum) {
		// TODO Auto-generated method stub		
	}
	@Override
	public int getTimeQuantum() {
		// TODO Auto-generated method stub
		return 0;
	}
}//ShortestJobFirst
