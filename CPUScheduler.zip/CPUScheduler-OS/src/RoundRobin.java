import java.util.HashMap;
import java.util.List;

public class RoundRobin extends CPUScheduler{	
	 private int timeQuantum;
	@Override
    public void process(){		
		List<Process> Processs = Utility.deepCopy(this.getProcesss());
        int time = Processs.get(0).getArrivalTime();
        int timeQuantum = this.getTimeQuantum();
        while (!Processs.isEmpty()){
            Process Process = Processs.get(0);
            int bt = (Process.getBurstTime() < timeQuantum ? Process.getBurstTime() : timeQuantum);
            // If the process burstTime is less than Q then BT is the burstTime of the process IF-ELSE then BT is the Q we entered.
            this.getTimeline().add(new Event(Process.getProcessName(), time, time + bt));
            time += bt;
            Processs.remove(0);            
            if (Process.getBurstTime() > timeQuantum){
                Process.setBurstTime(Process.getBurstTime() - timeQuantum);               
                for (int i = 0; i < Processs.size(); i++){
                     if (i == Processs.size() - 1){
                        Processs.add(Process);
                        break;
                    }//elseIF
                }//for
            }//if
        }//while
        HashMap<String, Integer> map = new HashMap<String,Integer>(); 
        for(Process Process : this.getProcesss()){
            map.clear();
            for(Event event : this.getTimeline()){	
                if(event.getProcessName().equals(Process.getProcessName())){               	
                    if(map.containsKey(event.getProcessName())){                   	
                        int w = event.getStartTime() - map.get(event.getProcessName());
                        Process.setWaitingTime(Process.getWaitingTime() + w);
                    }//if
                    else
                       Process.setWaitingTime(event.getStartTime() - Process.getArrivalTime());                    
                    map.put(event.getProcessName(), event.getFinishTime());
                }//if
            }//for  
            Process.setTurnaroundTime(Process.getWaitingTime() + Process.getBurstTime());
        }//for
    }//process
	@Override
	public void setTimeQuantum(int timeQuantum) {
	         this.timeQuantum = timeQuantum;
	}//setTimeQuantum
	@Override
	public int getTimeQuantum() {
		return timeQuantum;
	}//getTimeQuantum
}//RoundRobin
