import java.util.ArrayList;
import java.util.List;

public class Utility{
    public static List<Process> deepCopy(List<Process> oldList){   	
        List<Process> newList = new ArrayList<Process>();
        for (Process Process : oldList)
            newList.add(new Process(Process.getProcessName(),Process.getArrivalTime(), Process.getBurstTime()));
        return newList;
    }//deepCopy
}//Utility
