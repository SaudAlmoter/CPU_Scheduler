import java.util.ArrayList;
import java.util.List;

public abstract class CPUScheduler{
	
    private final List<Process> Processs;
    private final List<Event> timeline;
    
    public CPUScheduler(){
        Processs = new ArrayList<Process>();
        timeline = new ArrayList<Event>();
    }   
    public boolean add(Process Process){
        return Processs.add(Process);
    }   
    public double getAverageWaitingTime(){
        double avg = 0.0;       
        for (Process Process : Processs)
            avg += Process.getWaitingTime();
        return avg / Processs.size();
    }    
    public double getAverageTurnAroundTime(){
        double avg = 0.0;       
        for (Process Process : Processs)
            avg += Process.getTurnaroundTime();
        return avg / Processs.size();
    }    
    public Event getEvent(Process Process){
        for (Event event : timeline)
            if (Process.getProcessName().equals(event.getProcessName()))
                return event;
        return null;
    }  
    public Process getProcess(String process){
        for (Process Process : Processs)
            if (Process.getProcessName().equals(process))
                return Process;
        return null;
    }   
    public List<Process> getProcesss(){
        return Processs;
    }    
    public List<Event> getTimeline(){
        return timeline;
    }   
    public abstract void setTimeQuantum(int timeQuantum);
    
    public abstract int getTimeQuantum();
    
    public abstract void process();
}
