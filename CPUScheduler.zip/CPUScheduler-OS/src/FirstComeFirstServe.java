import java.util.List;

public class FirstComeFirstServe extends CPUScheduler{
    @Override
    public void process(){  
    	
        List<Event> timeline = this.getTimeline();
        
        for (Process Process : this.getProcesss()){
            if (timeline.isEmpty())
                timeline.add(new Event(Process.getProcessName(), Process.getArrivalTime(), Process.getArrivalTime() + Process.getBurstTime()));
            else{
                Event event = timeline.get(timeline.size() - 1);
                timeline.add(new Event(Process.getProcessName(), event.getFinishTime(), event.getFinishTime() + Process.getBurstTime()));
            	}//else
        }//for        
        for (Process Process : this.getProcesss()){
            Process.setWaitingTime(this.getEvent(Process).getStartTime() - Process.getArrivalTime());
            Process.setTurnaroundTime(Process.getWaitingTime() + Process.getBurstTime());
        }//for
    }//process

	@Override
	public void setTimeQuantum(int timeQuantum) {
		// TODO Auto-generated method stub
	}
	@Override
	public int getTimeQuantum() {
		// TODO Auto-generated method stub
		return 0;
	}
}//FirstComeFirstServe
