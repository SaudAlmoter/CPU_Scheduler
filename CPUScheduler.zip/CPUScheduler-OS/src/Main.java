import java.util.List;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Comparator;

public class Main{

	public static void main(String[] args){
		File fn = new File("C:\\Users\\Saud_\\Desktop\\saud's\\Semeter - 7\\CSC227\\CSC-227-TIT\\testdata1.txt");
		System.out.println("-----------------FCFS----------------");
		CPUScheduler  fcfs = fcfs(fn);
		System.out.println("-----------------SJF-----------------");
		CPUScheduler sjf = sjf(fn);
		System.out.println("-----------------RR3------------------");
		CPUScheduler rrQ2 = rr(3,fn);
		System.out.println("-----------------RR5------------------");
		CPUScheduler rrQ5 = rr(5,fn);
		compare(fcfs,sjf,rrQ2,rrQ5);
	}//mian
	static Scanner s = null;
	public static CPUScheduler fcfs(File fn){
		CPUScheduler fcfs = new FirstComeFirstServe();
		try {
			s = new Scanner(fn);
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String CPUB =" ";
		while (s.hasNextLine()) {

			String line = s.nextLine();
			if(s.hasNextLine())
				CPUB = s.nextLine();

			fcfs.add(new Process(line,Integer.parseInt(CPUB)));
		}//while
		fcfs.process();
		display(fcfs);
		return fcfs;
	}//fcfs
	public static CPUScheduler sjf(File fn){
		CPUScheduler sjf = new ShortestJobFirst();
		try {
			s = new Scanner(fn);
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String CPUB =" ";
		while (s.hasNextLine()) {

			String line = s.nextLine();
			if(s.hasNextLine())
				CPUB = s.nextLine();

			sjf.add(new Process(line, 0, Integer.parseInt(CPUB)));
		}//while
		sjf.process();
		display(sjf);
		return sjf;
	}//sjf
	public static CPUScheduler rr(int Q,File fn){
		CPUScheduler rr = new RoundRobin();
		rr.setTimeQuantum(Q);		
		try {
			s = new Scanner(fn);
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String CPUB =" ";
		while (s.hasNextLine()) {

			String line = s.nextLine();
			if(s.hasNextLine())
				CPUB = s.nextLine();

			rr.add(new Process(line,Integer.parseInt(CPUB)));
		}//while
		rr.process();
		display(rr);
		return rr;
	}//rr
	public static void display(CPUScheduler object){
		String name = object.getClass()+"";
		String[] n = name.split("class ");
		if(n[1].equalsIgnoreCase("ShortestJobFirst"))
			System.out.println("Process\tAT\tBT\tWT\tTAT");
		else
			System.out.println("Process\tBT\tWT\tTAT");
		for (Process Process : object.getProcesss()) {
			if(n[1].equalsIgnoreCase("ShortestJobFirst"))
				System.out.println(Process.getProcessName()+ "\t" + Process.getArrivalTime()+ "\t" + Process.getBurstTime() + "\t" + Process.getWaitingTime() + "\t" + Process.getTurnaroundTime());			
			else 
				System.out.println(Process.getProcessName()+ "\t" + Process.getBurstTime() + "\t" + Process.getWaitingTime() + "\t" + Process.getTurnaroundTime());
		}
		System.out.println();
		for (int i = 0; i < object.getTimeline().size(); i++){
			List<Event> timeline = object.getTimeline();
			System.out.print(timeline.get(i).getStartTime() + "(" + timeline.get(i).getProcessName() + ")");
			if (i == object.getTimeline().size() - 1)
				System.out.print(timeline.get(i).getFinishTime());
		}//for
		System.out.println("\n\nAverage WT: " + object.getAverageWaitingTime() + "\nAverage TAT: " + object.getAverageTurnAroundTime());
	}//display
	public static void compare(CPUScheduler fcfs, CPUScheduler sjf,CPUScheduler rr2,CPUScheduler rr5) {
		CPUScheduler[] TAT = new CPUScheduler[4];
		TAT[0] = fcfs;
		TAT[1] = sjf;
		TAT[2] = rr2;
		TAT[3] = rr5;
		System.out.println("-----------------COMPARESION_AverageTurnAroundTime------------------");

		Arrays.sort(TAT,Comparator.comparingDouble(CPUScheduler::getAverageTurnAroundTime));
		for(CPUScheduler d : TAT){
			String name = d.getClass()+"";
			String[] n = name.split("class ");
			if(d.getClass().isInstance(rr5))
				System.out.println(n[1] +"			"+d.getAverageTurnAroundTime()+"	WITH QUANTUM :	" + d.getTimeQuantum());
			else
				System.out.println(n[1] +"		"+d.getAverageTurnAroundTime());
		}//for
		System.out.println("-----------------COMPARESION_AverageWaitingTime------------------");
		Arrays.sort(TAT,Comparator.comparingDouble(CPUScheduler::getAverageWaitingTime));
		for(CPUScheduler d : TAT){
			String name = d.getClass()+"";
			String[] n = name.split("class ");
			if(d.getClass().isInstance(rr5))
				System.out.println(n[1] +"			"+d.getAverageWaitingTime()+"	WITH QUANTUM :	" + d.getTimeQuantum());
			else
				System.out.println(n[1] +"		"+d.getAverageWaitingTime());
		}//for
	}//compare
}//Main


